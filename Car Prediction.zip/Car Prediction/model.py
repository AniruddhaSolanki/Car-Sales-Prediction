#Car Sale Prediction Model

#Libraries
import numpy as np
import pandas as pd
import pickle

#Dataset
dataset = pd.read_csv('Car_Sales_Prediction.csv')
X = dataset.iloc[:, [1,2]].values
y = dataset.iloc[:, 3].values


#splitting the data set into training set and test set
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.25,random_state = 0)


#Fitting The Decision Tree Classifier to the Training set
from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(criterion = 'entropy',random_state = 0)
classifier.fit(X_train,y_train)

#Predicting the test set Results 
y_pred = classifier.predict(X_test)

#Making the confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test , y_pred)

# Saving model to disk
pickle.dump(classifier, open('model.pkl','wb'))

#Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))